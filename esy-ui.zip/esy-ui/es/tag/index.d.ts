import Tag from './Tag.js';



export { Tag as default };
