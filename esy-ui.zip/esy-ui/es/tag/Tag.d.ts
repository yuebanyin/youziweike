import { TagProps } from './types.js';
import React from 'react';

declare const Tag: React.FunctionComponent<TagProps>;

export { Tag as default };
