import { ReactNode } from 'react';
import { BaseComponent, ComponentType, DivMouseType, DivTouchType } from '../types.js';

interface TagClassNames {
    box?: string;
    'box:default'?: string;
    'box:primary'?: string;
    'box:primary:ghost'?: string;
    'box:success'?: string;
    'box:success:ghost'?: string;
    'box:warning'?: string;
    'box:warning:ghost'?: string;
    'box:error'?: string;
    'box:error:ghost'?: string;
    'box:checked'?: string;
    show?: string;
    hiddle?: string;
    close?: string;
    'checked:active'?: string;
}
interface TagProps extends BaseComponent {
    text?: string;
    type?: ComponentType & 'checked';
    isGhost?: boolean;
    isClose?: boolean;
    closeIcon?: ReactNode;
    onClose?: DivMouseType;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    classNames?: TagClassNames;
}

export { TagClassNames, TagProps };
