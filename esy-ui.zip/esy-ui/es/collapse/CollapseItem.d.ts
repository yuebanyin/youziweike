import * as react_jsx_runtime from 'react/jsx-runtime';
import { CollapseItemProps } from './types.js';

declare const CollapseItem: (props: CollapseItemProps) => react_jsx_runtime.JSX.Element;

export { CollapseItem as default };
