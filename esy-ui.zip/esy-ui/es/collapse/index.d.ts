import Collapse from './Collapse.js';



export { Collapse as default };
