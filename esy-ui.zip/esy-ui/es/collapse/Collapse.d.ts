import { CollapseProps } from './types.js';
import React from 'react';
import CollapseItem from './CollapseItem.js';

declare const Collapse: React.FC<CollapseProps> & {
    Item: typeof CollapseItem;
};

export { Collapse as default };
