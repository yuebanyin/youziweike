import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';

type CollapseItemKey = string | number | (string | number)[];
interface CollapseClassNames {
    box?: string;
    item?: string;
    'item:disabled'?: string;
    'item:nodisabled'?: string;
    'item:title'?: string;
    'item:border'?: string;
    'item:content'?: string;
    'item:content:child'?: string;
}
interface CollapseProps extends BaseComponent {
    isAccordion?: boolean;
    activeKey?: CollapseItemKey;
    divider?: boolean;
    border?: boolean;
    offset?: boolean;
    defaultActiveKey?: CollapseItemKey;
    classNames?: CollapseClassNames;
}
interface CollapseItemProps extends Pick<CollapseProps, 'border' | 'offset' | 'divider' | 'children' | 'classNames' | 'style'> {
    panelKey: string | number;
    title: ReactNode;
    disabled?: boolean;
    activeKeyList?: (string | number)[];
    changeActive?: (p: (string | number)[] | ((p?: (string | number)[]) => (string | number)[])) => void;
    isAccordion?: boolean;
}

export { CollapseClassNames, CollapseItemKey, CollapseItemProps, CollapseProps };
