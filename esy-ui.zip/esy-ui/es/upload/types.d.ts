import { BaseComponent, Func } from '../types.js';

interface UploadClassNames {
    box?: string;
    disabled?: string;
}
interface UploadProps extends BaseComponent {
    onUpload: Func;
    accept?: string;
    multiple?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    maxSize?: number;
    filesizecb?: Func;
    filetypecb?: Func;
    classNames?: UploadClassNames;
}

export { UploadClassNames, UploadProps };
