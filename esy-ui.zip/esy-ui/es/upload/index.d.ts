import Upload from './Upload.js';



export { Upload as default };
