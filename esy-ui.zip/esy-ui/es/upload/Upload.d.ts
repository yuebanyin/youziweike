import React from 'react';
import { UploadProps } from './types.js';

declare const Upload: React.FunctionComponent<UploadProps>;

export { Upload as default };
