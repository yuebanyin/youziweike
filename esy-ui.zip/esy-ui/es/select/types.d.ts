import { ReactNode } from 'react';
import { InputProps, InputClassNames } from '../input/types.js';
import { BaseComponent } from '../types.js';

type OptionItem = {
    text: string;
    value: string | number;
    label: ReactNode;
    id?: number;
};
interface SelectClassNames {
    box?: string;
    input?: InputClassNames;
    'input:expand'?: string;
    'input:retract'?: string;
    suffix?: string;
    'suffix:expand'?: string;
    'suffix:retract'?: string;
    value?: string;
    'value:expand'?: string;
    'value:retract'?: string;
    'value:mini'?: string;
    'value:small'?: string;
    'value:normal'?: string;
    'value:large'?: string;
    dropwrap?: string;
    dropdown?: string;
    'dropdown:expand'?: string;
    'dropdown:retract'?: string;
    options?: string;
    'options:expand'?: string;
    'options:retract'?: string;
    option?: string;
    'option:mini'?: string;
    'option:small'?: string;
    'option:normal'?: string;
    'option:large'?: string;
    'option:active'?: string;
    optiontext?: string;
    selectedicon?: string;
}
interface SelectProps extends Omit<InputProps, 'classNames'> {
    options?: OptionItem[];
    showSearch?: boolean;
    showSuffix?: boolean;
    onSelect?: (e?: OptionItem) => void;
    selectedIcon?: ReactNode;
    onChange?: (e?: string) => void;
    classNames?: SelectClassNames;
}
interface OptionProps extends OptionItem, BaseComponent, Pick<SelectProps, 'onSelect' | 'classNames' | 'size'> {
    active?: boolean;
    selectedicon?: ReactNode;
}

export { OptionItem, OptionProps, SelectClassNames, SelectProps };
