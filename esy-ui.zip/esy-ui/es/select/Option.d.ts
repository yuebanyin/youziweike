import * as react_jsx_runtime from 'react/jsx-runtime';
import { OptionProps } from './types.js';

declare const Option: (props: OptionProps) => react_jsx_runtime.JSX.Element;

export { Option as default };
