import { SelectProps } from './types.js';
import React from 'react';
import Option from './Option.js';

declare const Select: React.FC<SelectProps> & {
    Option: typeof Option;
};

export { Select as default };
