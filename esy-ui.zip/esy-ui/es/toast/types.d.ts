import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';

interface ToastClassNames {
    box?: string;
    mask?: string;
    'mask:none'?: string;
    'mask:auto'?: string;
    'icon:success'?: string;
    'icon:warn'?: string;
    'icon:error'?: string;
}
type StutasType = 'info' | 'success' | 'warn' | 'error';
interface InternalToastProps extends BaseComponent {
    content: string | ReactNode;
    type?: StutasType;
    duration?: number;
    onClose?: () => void;
    maskClickable?: boolean;
    classNames?: ToastClassNames;
}

export { InternalToastProps, StutasType, ToastClassNames };
