import { InternalToastProps } from './types.js';

declare const config: (options: Pick<InternalToastProps, 'duration' | 'maskClickable' | 'onClose'>) => void;
declare const show: (options: string | InternalToastProps) => void;
declare const clear: () => void;
interface ToastProps {
    show: typeof show;
    clear: typeof clear;
    config: typeof config;
}
declare const Toast: ToastProps;

export { ToastProps, Toast as default };
