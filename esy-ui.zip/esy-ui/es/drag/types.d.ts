import { BaseComponent, CommonDirection, DivMouseType } from '../types.js';

interface DragClassNames {
    box?: string;
    'box:disabled'?: string;
    'box:nodisabled'?: string;
}
interface DragProps extends BaseComponent {
    direction: CommonDirection;
    attraction: CommonDirection;
    disabled?: boolean;
    zIndex?: number;
    onClick?: DivMouseType;
    classNames?: DragClassNames;
}

export { DragClassNames, DragProps };
