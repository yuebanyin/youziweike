import React from 'react';
import { DragProps } from './types.js';

declare const Drag: React.FunctionComponent<DragProps>;

export { Drag as default };
