import React from 'react';
import { ConfigProviderProps } from './types.js';

declare const configContext: React.Context<Omit<ConfigProviderProps, "children">>;
declare const ConfigProvider: React.FunctionComponent<ConfigProviderProps> & {
    config: ConfigProviderProps;
    setConfig: Function;
};

export { configContext, ConfigProvider as default };
