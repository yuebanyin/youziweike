import React from 'react';
import { GroupProps } from './types.js';

declare const Group: React.FunctionComponent<GroupProps>;

export { Group as default };
