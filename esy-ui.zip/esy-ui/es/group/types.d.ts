import { BaseComponent, CommonDirection } from '../types.js';

interface GroupClassNames {
    'box:x'?: string;
    'box:y'?: string;
}
interface GroupProps extends BaseComponent {
    type: 'radio' | 'checked';
    defaultValue?: string | number;
    direction?: CommonDirection;
    value?: string | number;
    onChange?: (e: any) => void;
    classNames?: GroupClassNames;
}

export { GroupClassNames, GroupProps };
