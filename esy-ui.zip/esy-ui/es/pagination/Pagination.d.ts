import React from 'react';
import { PaginationProps } from './types.js';

declare const Pagination: React.FunctionComponent<PaginationProps>;

export { Pagination as default };
