import Pagination from './Pagination.js';



export { Pagination as default };
