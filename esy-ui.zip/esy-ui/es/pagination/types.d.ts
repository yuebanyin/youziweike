import { BaseComponent } from '../types.js';
import { InputClassNames } from '../input/types.js';
import { SelectClassNames } from '../select/types.js';

interface PaginationClassNames {
    box?: string;
    disabled?: string;
    prev?: string;
    previcon?: string;
    prevmore?: string;
    prevmoreicon?: string;
    moreiconmask?: string;
    next?: string;
    nexticon?: string;
    nextmore?: string;
    nextmoreicon?: string;
    moreicon?: string;
    page?: string;
    'page:hover'?: string;
    'page:active'?: string;
    'page:small'?: string;
    'page:mini'?: string;
    pagesize?: string;
    sizeselect?: SelectClassNames;
    pagejump?: string;
    jumpinput?: InputClassNames;
}
interface PaginationProps extends BaseComponent {
    pageIndex: number;
    pageSize: number;
    total: number;
    languageText?: {
        size: string;
        jump: string;
        page: string;
    };
    mini?: boolean;
    hideOnSinglePage?: boolean;
    showJump?: boolean;
    showSizeOptions?: boolean;
    pageSizeOptions?: string[];
    disabled?: boolean;
    classNames?: PaginationClassNames;
    onChange?: (i: number, s: number) => void;
}

export { PaginationClassNames, PaginationProps };
