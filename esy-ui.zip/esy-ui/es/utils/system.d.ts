declare const isMobile: boolean;

export { isMobile };
