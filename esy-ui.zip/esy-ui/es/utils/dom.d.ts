import { DivTouchParamType, DivMouseParamType, EventClickType } from '../types.js';

declare const createRipple: (rNode: HTMLElement) => (event: any) => void;
declare const removeRipple: () => void;
declare const thisGlobal: () => typeof globalThis;
declare function requestAnimationFrame(fn: any): number | NodeJS.Timeout;
declare function nextTickFrame(fn: any): void;
interface ScrollToOptions {
    top?: number;
    left?: number;
    duration?: number;
    animation?: (progress: number) => number;
}
declare function getScrollTop(element: Element | Window): number;
declare function getScrollLeft(element: Element | Window): number;
declare function scrollTo(element: HTMLElement | Window, { top, left, duration, animation, }: ScrollToOptions): Promise<void>;
declare const getAllChildNodes: (parantsNode: any) => any[];
declare const getInsertRoot: () => HTMLElement;
declare const createTagInBody: (dom: HTMLElement, style?: boolean) => (fn?: () => void) => void;
declare const getClientXY: (e: DivTouchParamType | DivMouseParamType, eventType: EventClickType) => {
    x: any;
    y: any;
};
declare const getDomBoundary: (el: any) => {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    st: number;
    sl: number;
};

export { createRipple, createTagInBody, getAllChildNodes, getClientXY, getDomBoundary, getInsertRoot, getScrollLeft, getScrollTop, nextTickFrame, removeRipple, requestAnimationFrame, scrollTo, thisGlobal };
