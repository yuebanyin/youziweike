declare function class_bem(prefix: string, tagName: string, otherArr?: string[], cn?: string): string;
declare function class_esy(def_cn?: string[], cn?: string): string;

export { class_bem, class_esy };
