import dayjs from 'dayjs';
import { Obj, Func } from '../types.js';

declare const isNoEmpty: (p: any) => boolean;
declare const isObject: (t: Obj) => boolean;
declare const isArray: (arr: any) => boolean;
declare const omit: (sourceObj: Obj, ignoreKeys: string[]) => Obj;
declare const pick: (sourceObj: Obj, drawOutKeys: string[]) => Obj;
declare const debounce: (func: Func, delay?: number) => () => void;
declare const throttle: (func: Func, delay?: number) => () => void;
declare const copyText: (text: string, successcb?: Func, failcb?: Func) => void;
declare const getRandomNumber: (dight?: number) => string;
declare const openLocalFolder: (accept?: string, multiple?: boolean) => Promise<unknown>;
declare const uuid: (len?: number) => string;
declare const isPromise: (pm: any) => boolean;
declare const stopDefault: (e: any) => boolean;
declare const stopPropagation: (e: any) => void;
declare const imgLazyload: (({ loadingFn }: {
    loadingFn?: Func;
}) => void) | (({ observerFn }: {
    observerFn?: Func;
}) => void) | (({ cb }: {
    cb?: Func;
}) => void);
declare const zeroFill: (num: number, len: number, isPre?: boolean) => string | number;
declare const formatCDT: (t: number) => {
    s: string | number;
    m: string | number;
    h: string | number;
    d: number;
};
declare const getFirstDay: (t: any) => dayjs.Dayjs;
declare const getEndDay: (t: any) => dayjs.Dayjs;
declare const getUnitTime: (props: {
    ny?: number;
    nm?: number;
    nd?: number;
    type?: 'add' | 'subt';
    strType?: string;
}) => {
    y: any;
    m: any;
    days: any[];
};
declare const getMonths: (y: any, type?: string) => any[];
declare const getYears: (y: any) => {
    years: {
        year: dayjs.Dayjs;
        yearStr: string;
        text: string;
    }[];
    range: string[];
};

export { copyText, debounce, formatCDT, getEndDay, getFirstDay, getMonths, getRandomNumber, getUnitTime, getYears, imgLazyload, isArray, isNoEmpty, isObject, isPromise, omit, openLocalFolder, pick, stopDefault, stopPropagation, throttle, uuid, zeroFill };
