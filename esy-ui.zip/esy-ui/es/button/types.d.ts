import { ButtonHTMLAttributes, MouseEventHandler, TouchEventHandler } from 'react';
import { BaseComponent, ComponentSize, ComponentType } from '../types.js';

type ButtonMouseType = MouseEventHandler<HTMLButtonElement>;
type ButtonTouchType = TouchEventHandler<HTMLButtonElement>;
interface ButtonClassNames {
    box?: string;
    'box:mini'?: string;
    'box:small'?: string;
    'box:normal'?: string;
    'box:large'?: string;
    'box:default'?: string;
    'box:primary'?: string;
    'box:link'?: string;
    'box:ghost'?: string;
    'box:success'?: string;
    'box:warning'?: string;
    'box:error'?: string;
    'box:disabled'?: string;
}
interface ButtonProps extends BaseComponent {
    size?: ComponentSize;
    type?: (ComponentType & 'link' & 'ghost' & 'disabled') | string;
    htmltype?: ButtonHTMLAttributes<HTMLButtonElement>['type'];
    text?: string;
    loading?: boolean;
    changeLoading?: (v?: any) => {};
    isRipple?: boolean;
    onClick?: ButtonMouseType;
    onTouchStart?: ButtonTouchType;
    classNames?: ButtonClassNames;
}

export { ButtonClassNames, ButtonMouseType, ButtonProps, ButtonTouchType };
