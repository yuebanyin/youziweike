import { ButtonProps } from './types.js';
import React from 'react';

declare const Button: React.FunctionComponent<ButtonProps>;

export { Button as default };
