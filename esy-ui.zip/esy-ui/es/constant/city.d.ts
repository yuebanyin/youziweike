declare const cityList: {
    text: string;
    key: string;
    children: {
        text: string;
        key: string;
        children: {
            text: string;
            key: string;
        }[];
    }[];
}[];

export { cityList };
