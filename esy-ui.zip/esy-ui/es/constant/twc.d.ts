declare const tailwindcssTheme: {
    theme: {
        fontSize: {
            mini: string[];
        };
    };
    extend: {
        colors: {
            primary: string;
            'primary-text': string;
            default: string;
            'primary-hover': string;
            success: string;
            warning: string;
            error: string;
            'primary-ipt': string;
            'primary-ipt-hover': string;
            'disabled-text': string;
            disabled: string;
            split: string;
            desc: string;
            label: string;
            mask: string;
            clear: string;
            placeholder: string;
            icon: string;
            'table-header': string;
        };
        animation: {
            'checked-animate': string;
            'translate-x-100-0': string;
            'translate-x-0-100': string;
            'translate-x-m100-0': string;
            skeleton: string;
            'translate-x-0-m100': string;
            'translate-y-m100-0': string;
            'translate-y-0-m100': string;
            'translate-y-100-0': string;
            'translate-y-0-100': string;
            'zoom-0-100': string;
            'zoom-100-0': string;
            'opacity-100-0': string;
            'rotate-0-360': string;
            'scale-y-1-2': string;
            cube: string;
            'move-down-to-up': string;
            'standard-line': string;
            'scroll-x': string;
        };
        keyframes: {
            'checked-animate': {
                '0%': {
                    transform: string;
                };
                '50%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-x-100-0': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-x-0-100': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-x-m100-0': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-x-0-m100': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-y-m100-0': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-y-0-m100': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-y-100-0': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'translate-y-0-100': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'zoom-0-100': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'zoom-100-0': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'opacity-100-0': {
                '0%': {
                    opacity: string;
                };
                '100%': {
                    opacity: string;
                };
            };
            'rotate-0-360': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'scale-y-1-2': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            cube: {
                '0%': {
                    transform: string;
                    opacity: string;
                };
                '100%': {
                    transform: string;
                    opacity: string;
                };
            };
            'move-down-to-up': {
                '0%': {
                    transform: string;
                    opacity: string;
                };
                '100%': {
                    transform: string;
                    opacity: string;
                };
            };
            'standard-line': {
                '0%': {
                    transform: string;
                };
                '10%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
            'scroll-x': {
                '0%': {
                    transform: string;
                };
                '100%': {
                    transform: string;
                };
            };
        };
        zIndex: {
            '1': string;
            '2': string;
            '100': string;
            '101': string;
            '102': string;
            '1000': string;
        };
        boxShadow: {
            card: string;
        };
        borderRadius: {
            '2/5': string;
            half: string;
        };
        transitionProperty: {
            border: string;
            filter: string;
            'z-index': string;
            'border-bg-color': string;
            'left-top': string;
        };
        backgroundImage: {
            'white-gray-1': string;
            skeleton: string;
        };
        backgroundPosition: {
            'top-bottom': string;
        };
        spacing: {
            '4.5': string;
            '1/5': string;
            '7/10': string;
            '2/5': string;
            '3/5': string;
            '13/50': string;
            '17/20': string;
            '2/1': string;
        };
        scale: {
            '85': string;
        };
        transitionDuration: {
            '250': string;
        };
        flex: {
            '1-0-auto': string;
            '1/3': string;
        };
    };
};

export { tailwindcssTheme };
