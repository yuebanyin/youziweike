import HorizolScroll from './HorizolScroll.js';



export { HorizolScroll as default };
