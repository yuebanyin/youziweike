import { BaseComponent, Obj } from '../types.js';

interface HorizolScrollClassNames {
    box?: string;
    list?: string;
    animation?: string;
    text?: string;
}
interface HorizolScrollListItem extends Obj {
    id: number | string;
    text: string;
    url?: string;
}
interface HorizolScrollProps extends BaseComponent {
    list?: HorizolScrollListItem[];
    onClick?: (item?: HorizolScrollListItem) => void;
    onTouchStart?: (item?: HorizolScrollListItem) => void;
    classNames?: HorizolScrollClassNames;
    isAnimation?: boolean;
    speedRate?: number;
}

export { HorizolScrollClassNames, HorizolScrollListItem, HorizolScrollProps };
