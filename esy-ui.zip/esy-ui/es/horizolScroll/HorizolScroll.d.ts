import React from 'react';
import { HorizolScrollProps } from './types.js';

declare const HorizolScroll: React.FunctionComponent<HorizolScrollProps>;

export { HorizolScroll as default };
