import React from 'react';
import { DivMouseType } from '../types.js';

interface IframeClassNames {
    box?: string;
    iframe?: string;
}
interface IframeProps extends React.DetailedHTMLProps<React.IframeHTMLAttributes<HTMLIFrameElement>, HTMLIFrameElement> {
    classNames?: IframeClassNames;
    boxClassName?: string;
    onClick?: DivMouseType;
}

export { IframeClassNames, IframeProps };
