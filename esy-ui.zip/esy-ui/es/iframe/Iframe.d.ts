import React from 'react';
import { IframeProps } from './types.js';

declare const Iframe: React.FC<IframeProps>;

export { Iframe as default };
