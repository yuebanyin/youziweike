import React from 'react';
import { InputClassNames } from '../input/types.js';
import { TableClassNames } from '../table/types.js';
import { ComponentSize } from '../types.js';

interface DateText {
    y?: string;
    m?: string;
    w1?: string;
    w2?: string;
    w3?: string;
    w4?: string;
    w5?: string;
    w6?: string;
    w0?: string;
}
interface DatePickerClassNames {
    box?: string;
    header?: string;
    icons?: string;
    icon?: string;
    title?: string;
    year?: string;
    month?: string;
    content?: string;
    'content:months': string;
    'content:years': string;
    tablebox?: string;
    table?: TableClassNames;
    monthbox?: string;
    yearbox?: string;
    ymchild?: string;
    text?: string;
    'text:hover'?: string;
    'text:active'?: string;
    input?: InputClassNames;
    day?: string;
    'day:show'?: string;
    'day:hidden'?: string;
    'day:disabled'?: string;
    'day:selected'?: string;
    'day:today'?: string;
    footer?: string;
}
interface DatePickerProps {
    text?: DateText;
    type?: 'YYYY-MM-DD' | 'YYYY/MM/DD' | 'YYYYMMDD';
    classNames?: DatePickerClassNames;
    onChange?: (v?: any) => void;
    value?: string;
    defaultValue?: string;
    size?: ComponentSize;
    readOnly?: boolean;
    disabled?: boolean;
    disabledDate?: (dateStr: string) => boolean;
    renderExtraFooter?: React.ReactNode;
}

export { DatePickerClassNames, DatePickerProps, DateText };
