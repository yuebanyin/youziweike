import React from 'react';
import { DatePickerProps } from './types.js';

declare const DatePicker: React.FunctionComponent<DatePickerProps>;

export { DatePicker as default };
