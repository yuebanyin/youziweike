import React from 'react';
import { CellProps } from './types.js';

declare const Cell: React.FunctionComponent<CellProps>;

export { Cell as default };
