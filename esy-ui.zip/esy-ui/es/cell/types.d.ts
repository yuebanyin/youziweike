import { ReactNode } from 'react';
import { BaseComponent, DivMouseType, DivTouchType } from '../types.js';

type CellType = 'border' | 'border-none' | 'card' | 'border-bottom';
interface CellClassNames {
    box?: string;
    'box:border-bottom'?: string;
    'box:border'?: string;
    'box:border-none'?: string;
    'box:card'?: string;
    content?: string;
    'content:title'?: string;
    'content:desc'?: string;
}
interface CellProps extends BaseComponent {
    title: string;
    description?: string;
    leftSlot?: ReactNode;
    rightSlot?: ReactNode;
    isRipple?: boolean;
    type?: CellType;
    classNames?: CellClassNames;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
}

export { CellClassNames, CellProps, CellType };
