import { ConfigOptions, InternalMessageProps } from './types.js';

declare const config: (options: ConfigOptions) => void;
declare const show: (options: string | InternalMessageProps) => void;
declare const clear: (key?: string) => void;
interface MessageProps {
    show: typeof show;
    clear: typeof clear;
    config: typeof config;
}
declare const Message: MessageProps;

export { MessageProps, Message as default };
