import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';

interface MessageClassNames {
    box?: string;
    mask?: string;
    'icon:success'?: string;
    'icon:warn'?: string;
    'icon:error'?: string;
}
interface InternalMessageProps extends BaseComponent {
    content: string | ReactNode;
    type?: 'info' | 'success' | 'warn' | 'error';
    duration?: number;
    key?: string;
    onClose?: () => void;
    classNames?: MessageClassNames;
}
interface ConfigOptions extends Pick<InternalMessageProps, 'duration' | 'onClose'> {
    maxCount?: number;
}

export { ConfigOptions, InternalMessageProps, MessageClassNames };
