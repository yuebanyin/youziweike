import Link from './Link.js';



export { Link as default };
