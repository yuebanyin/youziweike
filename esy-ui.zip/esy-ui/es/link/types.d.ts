import { BaseComponent, ComponentType, ComponentTarget } from '../types.js';

type Underline = 'always' | 'hover' | 'none';
interface LinkClassNames {
    box?: string;
    'box:default'?: string;
    'box:primary'?: string;
    'box:success'?: string;
    'box:warning'?: string;
    'box:error'?: string;
    'box:disabled'?: string;
    'box:underline:none'?: string;
    'box:underline:hover'?: string;
    'box:underline:always'?: string;
}
interface LinkProps extends BaseComponent {
    text?: string;
    href: string;
    rel?: string;
    type?: ComponentType;
    underline?: Underline;
    target?: ComponentTarget;
    classNames?: LinkClassNames;
}

export { LinkClassNames, LinkProps, Underline };
