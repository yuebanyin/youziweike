import React from 'react';
import { LinkProps } from './types.js';

declare const Link: React.FunctionComponent<LinkProps>;

export { Link as default };
