import { ReactNode } from 'react';
import { BaseComponent, ComponentSize } from '../types.js';

declare class TitleItem {
    title: ReactNode;
    index: number;
    paneKey: string;
    disabled: boolean;
    children: ReactNode;
}
type TabDirection = 'horizontal' | 'vertical';
interface TabsClassNames {
    box?: string;
    'box:horizontal'?: string;
    'box:vertical'?: string;
    titles?: string;
    'titles:horizontal'?: string;
    'titles:vertical'?: string;
    title?: string;
    'title:horizontal'?: string;
    'title:vertical'?: string;
    'title:disabled'?: string;
    'title:nodisabled'?: string;
    'title:mini'?: string;
    'title:small'?: string;
    'title:normal'?: string;
    'title:large'?: string;
    'title:active'?: string;
    indicator?: string;
    'indicator:horizontal'?: string;
    'indicator:vertical'?: string;
    content?: string;
    'content:horizontal'?: string;
    'content:vertical'?: string;
    contentitem?: string;
    'contentitem:horizontal'?: string;
    'contentitem:vertical'?: string;
}
interface TabsProps extends BaseComponent {
    tabs: TitleItem[];
    direction?: TabDirection;
    activeKey?: string;
    animateTime?: number;
    defaultActiveKey?: string;
    size?: ComponentSize;
    isRipple?: boolean;
    isDestroyUnactive?: boolean;
    indicatorRatio?: number;
    classNames?: TabsClassNames;
    onClick?: (item?: TitleItem) => void;
    onTouchStart?: (item?: TitleItem) => void;
}
interface TabsItemProps extends Omit<TabsProps, 'tabs'> {
    title: ReactNode;
    paneKey: string;
    disabled?: boolean;
    currentItem?: TitleItem;
    prefix?: string;
}

export { TabDirection, TabsClassNames, TabsItemProps, TabsProps, TitleItem };
