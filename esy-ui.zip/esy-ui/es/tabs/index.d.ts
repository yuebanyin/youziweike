import Tabs from './Tabs.js';



export { Tabs as default };
