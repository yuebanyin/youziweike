import React from 'react';
import { TabsProps } from './types.js';
import TabItem from './TabItem.js';

declare const Tabs: React.FC<TabsProps> & {
    Item: typeof TabItem;
};

export { Tabs as default };
