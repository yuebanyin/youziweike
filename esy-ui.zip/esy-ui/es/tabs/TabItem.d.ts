import * as react_jsx_runtime from 'react/jsx-runtime';
import { TabsItemProps } from './types.js';

declare const TabItem: (props: TabsItemProps) => react_jsx_runtime.JSX.Element;

export { TabItem as default };
