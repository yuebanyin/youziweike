import React from 'react';
import { IconProps } from '../../types.js';

declare const AboutTwoTone: React.FC<IconProps>;

export { AboutTwoTone as default };
