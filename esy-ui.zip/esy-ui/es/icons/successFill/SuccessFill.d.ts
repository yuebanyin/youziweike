import React from 'react';
import { IconProps } from '../../types.js';

declare const SuccessFill: React.FC<IconProps>;

export { SuccessFill as default };
