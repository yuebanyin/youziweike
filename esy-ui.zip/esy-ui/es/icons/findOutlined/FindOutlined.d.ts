import React from 'react';
import { IconProps } from '../../types.js';

declare const FindOutlined: React.FC<IconProps>;

export { FindOutlined as default };
