import React from 'react';
import { IconProps } from '../../types.js';

declare const VerifyOutlined: React.FC<IconProps>;

export { VerifyOutlined as default };
