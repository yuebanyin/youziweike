import React from 'react';
import { IconProps } from '../../types.js';

declare const MessageTwoTone: React.FC<IconProps>;

export { MessageTwoTone as default };
