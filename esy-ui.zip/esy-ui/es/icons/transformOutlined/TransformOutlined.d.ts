import React from 'react';
import { IconProps } from '../../types.js';

declare const TransformOutlined: React.FC<IconProps>;

export { TransformOutlined as default };
