import React from 'react';
import { IconProps } from '../../types.js';

declare const CabinetTwoTone: React.FC<IconProps>;

export { CabinetTwoTone as default };
