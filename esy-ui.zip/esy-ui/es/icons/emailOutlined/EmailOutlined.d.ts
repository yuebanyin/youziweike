import React from 'react';
import { IconProps } from '../../types.js';

declare const EmailOutlined: React.FC<IconProps>;

export { EmailOutlined as default };
