import React from 'react';
import { IconProps } from '../../types.js';

declare const ArrowDownOutlined: React.FC<IconProps>;

export { ArrowDownOutlined as default };
