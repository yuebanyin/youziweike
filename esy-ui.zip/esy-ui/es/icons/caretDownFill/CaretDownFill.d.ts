import React from 'react';
import { IconProps } from '../../types.js';

declare const CaretDownFill: React.FC<IconProps>;

export { CaretDownFill as default };
