import React from 'react';
import { IconProps } from '../../types.js';

declare const CloseOutlined: React.FC<IconProps>;

export { CloseOutlined as default };
