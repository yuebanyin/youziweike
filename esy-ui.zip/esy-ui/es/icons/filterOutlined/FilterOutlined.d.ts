import React from 'react';
import { IconProps } from '../../types.js';

declare const FilterOutlined: React.FC<IconProps>;

export { FilterOutlined as default };
