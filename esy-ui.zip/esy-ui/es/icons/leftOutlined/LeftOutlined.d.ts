import React from 'react';
import { IconProps } from '../../types.js';

declare const LeftOutlined: React.FC<IconProps>;

export { LeftOutlined as default };
