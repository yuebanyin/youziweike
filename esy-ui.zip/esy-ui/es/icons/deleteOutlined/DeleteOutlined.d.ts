import React from 'react';
import { IconProps } from '../../types.js';

declare const DeleteOutlined: React.FC<IconProps>;

export { DeleteOutlined as default };
