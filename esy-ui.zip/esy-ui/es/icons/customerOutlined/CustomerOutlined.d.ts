import React from 'react';
import { IconProps } from '../../types.js';

declare const CustomerOutlined: React.FC<IconProps>;

export { CustomerOutlined as default };
