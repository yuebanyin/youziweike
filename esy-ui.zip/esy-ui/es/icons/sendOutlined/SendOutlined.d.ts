import React from 'react';
import { IconProps } from '../../types.js';

declare const SendOutlined: React.FC<IconProps>;

export { SendOutlined as default };
