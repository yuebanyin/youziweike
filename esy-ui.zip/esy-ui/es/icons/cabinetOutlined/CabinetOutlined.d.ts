import React from 'react';
import { IconProps } from '../../types.js';

declare const CabinetOutlined: React.FC<IconProps>;

export { CabinetOutlined as default };
