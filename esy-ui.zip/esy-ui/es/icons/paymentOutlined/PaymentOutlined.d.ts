import React from 'react';
import { IconProps } from '../../types.js';

declare const PaymentOutlined: React.FC<IconProps>;

export { PaymentOutlined as default };
