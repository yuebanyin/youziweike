import React from 'react';
import { IconProps } from '../../types.js';

declare const CameraOutlined: React.FC<IconProps>;

export { CameraOutlined as default };
