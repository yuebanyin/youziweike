import React from 'react';
import { IconProps } from '../../types.js';

declare const EyeOutlined: React.FC<IconProps & {
    type: 'hidden' | 'show';
}>;

export { EyeOutlined as default };
