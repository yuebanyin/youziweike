import React from 'react';
import { IconProps } from '../../types.js';

declare const ArrowLeftOutlined: React.FC<IconProps>;

export { ArrowLeftOutlined as default };
