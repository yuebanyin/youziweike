import React from 'react';
import { IconProps } from '../../types.js';

declare const HammerOutlined: React.FC<IconProps>;

export { HammerOutlined as default };
