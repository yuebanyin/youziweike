import React from 'react';
import { IconProps } from '../../types.js';

declare const CubeTwoTone: React.FC<IconProps>;

export { CubeTwoTone as default };
