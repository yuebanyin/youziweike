import React from 'react';
import { IconProps } from '../../types.js';

declare const QRcodeOutlined: React.FC<IconProps>;

export { QRcodeOutlined as default };
