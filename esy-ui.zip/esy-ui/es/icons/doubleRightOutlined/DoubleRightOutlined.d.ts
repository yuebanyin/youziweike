import React from 'react';
import { IconProps } from '../../types.js';

declare const DoubleRightOutlined: React.FC<IconProps>;

export { DoubleRightOutlined as default };
