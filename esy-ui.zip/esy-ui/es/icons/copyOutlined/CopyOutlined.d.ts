import React from 'react';
import { IconProps } from '../../types.js';

declare const CopyOutlined: React.FC<IconProps>;

export { CopyOutlined as default };
