import React from 'react';
import { IconProps } from '../../types.js';

declare const CaretUpFill: React.FC<IconProps>;

export { CaretUpFill as default };
