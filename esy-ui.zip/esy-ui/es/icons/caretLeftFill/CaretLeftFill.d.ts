import React from 'react';
import { IconProps } from '../../types.js';

declare const CaretLeftFill: React.FC<IconProps>;

export { CaretLeftFill as default };
