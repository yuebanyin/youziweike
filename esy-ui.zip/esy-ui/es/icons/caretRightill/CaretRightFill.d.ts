import React from 'react';
import { IconProps } from '../../types.js';

declare const CaretRightFill: React.FC<IconProps>;

export { CaretRightFill as default };
