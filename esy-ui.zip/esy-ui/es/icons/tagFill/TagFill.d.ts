import React from 'react';
import { IconProps } from '../../types.js';

declare const TagFill: React.FC<IconProps>;

export { TagFill as default };
