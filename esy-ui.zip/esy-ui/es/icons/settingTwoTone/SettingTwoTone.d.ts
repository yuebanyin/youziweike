import React from 'react';
import { IconProps } from '../../types.js';

declare const SettingTwoTone: React.FC<IconProps>;

export { SettingTwoTone as default };
