import React from 'react';
import { IconProps } from '../../types.js';

declare const PhoneTwoTone: React.FC<IconProps>;

export { PhoneTwoTone as default };
