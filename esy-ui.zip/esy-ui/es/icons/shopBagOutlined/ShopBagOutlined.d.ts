import React from 'react';
import { IconProps } from '../../types.js';

declare const ShopBagOutlined: React.FC<IconProps>;

export { ShopBagOutlined as default };
