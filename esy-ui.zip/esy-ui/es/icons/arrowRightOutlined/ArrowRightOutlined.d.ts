import React from 'react';
import { IconProps } from '../../types.js';

declare const ArrowRightOutlined: React.FC<IconProps>;

export { ArrowRightOutlined as default };
