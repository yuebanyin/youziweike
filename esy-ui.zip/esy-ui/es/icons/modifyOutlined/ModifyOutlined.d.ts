import React from 'react';
import { IconProps } from '../../types.js';

declare const ModifyOutlined: React.FC<IconProps>;

export { ModifyOutlined as default };
