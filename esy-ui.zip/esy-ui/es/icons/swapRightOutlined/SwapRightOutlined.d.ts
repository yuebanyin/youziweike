import React from 'react';
import { IconProps } from '../../types.js';

declare const SwapRightOutlined: React.FC<IconProps>;

export { SwapRightOutlined as default };
