import React from 'react';
import { IconProps } from '../../types.js';

declare const ShopCartFill: React.FC<IconProps>;

export { ShopCartFill as default };
