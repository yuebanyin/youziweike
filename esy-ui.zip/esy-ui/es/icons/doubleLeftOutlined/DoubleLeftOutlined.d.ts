import React from 'react';
import { IconProps } from '../../types.js';

declare const DoubleLeftOutlined: React.FC<IconProps>;

export { DoubleLeftOutlined as default };
