import React from 'react';
import { IconProps } from '../../types.js';

declare const WarnFill: React.FC<IconProps>;

export { WarnFill as default };
