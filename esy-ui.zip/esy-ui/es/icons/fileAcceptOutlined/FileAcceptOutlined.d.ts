import React from 'react';
import { IconProps } from '../../types.js';

declare const FileAcceptOutlined: React.FC<IconProps>;

export { FileAcceptOutlined as default };
