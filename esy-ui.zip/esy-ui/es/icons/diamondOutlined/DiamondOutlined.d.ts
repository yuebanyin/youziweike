import React from 'react';
import { IconProps } from '../../types.js';

declare const DiamondOutlined: React.FC<IconProps>;

export { DiamondOutlined as default };
