import React from 'react';
import { IconProps } from '../../types.js';

declare const CubeOutlined: React.FC<IconProps>;

export { CubeOutlined as default };
