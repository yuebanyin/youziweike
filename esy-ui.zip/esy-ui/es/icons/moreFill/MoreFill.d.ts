import React from 'react';
import { IconProps } from '../../types.js';

declare const MoreFill: React.FC<IconProps>;

export { MoreFill as default };
