import React from 'react';
import { IconProps } from '../../types.js';

declare const SyncOutlined: React.FC<IconProps>;

export { SyncOutlined as default };
