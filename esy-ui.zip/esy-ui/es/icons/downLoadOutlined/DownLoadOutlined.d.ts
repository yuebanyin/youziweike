import React from 'react';
import { IconProps } from '../../types.js';

declare const DownOutlined: React.FC<IconProps>;

export { DownOutlined as default };
