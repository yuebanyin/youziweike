import React from 'react';
import { IconProps } from '../../types.js';

declare const AddOutlined: React.FC<IconProps>;

export { AddOutlined as default };
