import React from 'react';
import { IconProps } from '../../types.js';

declare const RightOutlined: React.FC<IconProps>;

export { RightOutlined as default };
