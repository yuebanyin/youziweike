import React from 'react';
import { IconProps } from '../../types.js';

declare const ShareOutlined: React.FC<IconProps>;

export { ShareOutlined as default };
