import React from 'react';
import { IconProps } from '../../types.js';

declare const QuestionOutlined: React.FC<IconProps>;

export { QuestionOutlined as default };
