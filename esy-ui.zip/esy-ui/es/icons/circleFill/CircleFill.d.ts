import React from 'react';
import { IconProps } from '../../types.js';

declare const CircleFill: React.FC<IconProps>;

export { CircleFill as default };
