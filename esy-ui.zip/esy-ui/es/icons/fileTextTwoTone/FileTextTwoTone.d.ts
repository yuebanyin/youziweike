import React from 'react';
import { IconProps } from '../../types.js';

declare const FileTextTwoTone: React.FC<IconProps>;

export { FileTextTwoTone as default };
