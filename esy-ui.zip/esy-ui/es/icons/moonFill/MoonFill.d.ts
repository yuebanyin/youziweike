import React from 'react';
import { IconProps } from '../../types.js';

declare const MoonFill: React.FC<IconProps>;

export { MoonFill as default };
