import React from 'react';
import { IconProps } from '../../types.js';

declare const TickOutlined: React.FC<IconProps>;

export { TickOutlined as default };
