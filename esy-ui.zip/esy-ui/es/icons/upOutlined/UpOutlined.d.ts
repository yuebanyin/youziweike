import React from 'react';
import { IconProps } from '../../types.js';

declare const UpOutlined: React.FC<IconProps>;

export { UpOutlined as default };
