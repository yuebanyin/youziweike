import React from 'react';
import { IconProps } from '../../types.js';

declare const EditOutlined: React.FC<IconProps>;

export { EditOutlined as default };
