import React from 'react';
import { IconProps } from '../../types.js';

declare const StarOutlined: React.FC<IconProps>;

export { StarOutlined as default };
