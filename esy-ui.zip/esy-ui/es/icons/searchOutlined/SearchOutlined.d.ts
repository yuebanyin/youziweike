import React from 'react';
import { IconProps } from '../../types.js';

declare const SearchOutlined: React.FC<IconProps>;

export { SearchOutlined as default };
