import React from 'react';
import { IconProps } from '../../types.js';

declare const CloseFill: React.FC<IconProps>;

export { CloseFill as default };
