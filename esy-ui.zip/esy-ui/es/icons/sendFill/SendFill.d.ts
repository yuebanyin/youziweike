import React from 'react';
import { IconProps } from '../../types.js';

declare const SendFill: React.FC<IconProps>;

export { SendFill as default };
