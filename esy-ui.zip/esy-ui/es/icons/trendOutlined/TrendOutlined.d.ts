import React from 'react';
import { IconProps } from '../../types.js';

declare const TrendOutlined: React.FC<IconProps>;

export { TrendOutlined as default };
