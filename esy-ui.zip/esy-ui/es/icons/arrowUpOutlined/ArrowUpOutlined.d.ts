import React from 'react';
import { IconProps } from '../../types.js';

declare const ArrowUpOutlined: React.FC<IconProps>;

export { ArrowUpOutlined as default };
