import React from 'react';
import { IconProps } from '../../types.js';

declare const QuitOutlined: React.FC<IconProps>;

export { QuitOutlined as default };
