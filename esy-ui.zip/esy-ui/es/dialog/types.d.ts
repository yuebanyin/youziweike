import { ReactNode } from 'react';
import { BaseComponent, TBLRC } from '../types.js';

interface DialogClassNames {
    mask?: string;
    'mask:center'?: string;
    box?: string;
    'box:right'?: string;
    'box:right:apper'?: string;
    'box:right:disapper'?: string;
    'box:left'?: string;
    'box:left:apper'?: string;
    'box:left:disapper'?: string;
    'box:top'?: string;
    'box:top:apper'?: string;
    'box:top:disapper'?: string;
    'box:bottom'?: string;
    'box:bottom:apper'?: string;
    'box:bottom:disapper'?: string;
    'box:center'?: string;
    'box:center:apper'?: string;
    'box:center:disapper'?: string;
    title?: string;
    'title:icon'?: string;
    'title:noicon'?: string;
    'close:icon'?: string;
}
interface DialogProps extends BaseComponent {
    open: boolean;
    onClose?: (e?: any) => void;
    title?: ReactNode;
    footer?: ReactNode;
    closeIcon?: ReactNode | boolean;
    direction?: TBLRC;
    classNames?: DialogClassNames;
}

export { DialogClassNames, DialogProps };
