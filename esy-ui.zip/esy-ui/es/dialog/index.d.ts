import Dialog from './Dialog.js';



export { Dialog as default };
