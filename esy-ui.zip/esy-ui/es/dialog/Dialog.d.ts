import React from 'react';
import { DialogProps } from './types.js';

declare const confirm: (props: Omit<DialogProps, 'open'>) => void;
declare const Dialog: React.FC<DialogProps> & {
    confirm: typeof confirm;
};

export { Dialog as default };
