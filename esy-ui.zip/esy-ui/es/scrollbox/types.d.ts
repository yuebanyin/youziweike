import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';
import { LoadingClassNames } from '../loading/types.js';

interface ScrollboxClassNames {
    box?: string;
    more?: string;
    loading?: LoadingClassNames;
}
interface ScrollboxProps extends BaseComponent {
    list: any[];
    historyTotal: number;
    loadMoreData?: (e?: any) => void;
    heightOffset?: number;
    moreText?: ReactNode;
    moreTextEnd?: ReactNode;
    loading?: boolean;
    loadingIcon?: ReactNode;
    onScroll?: (e: any) => void;
    classNames?: ScrollboxClassNames;
    boxClassName?: string;
}

export { ScrollboxClassNames, ScrollboxProps };
