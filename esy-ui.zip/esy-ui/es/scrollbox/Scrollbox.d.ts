import React from 'react';
import { ScrollboxProps } from './types.js';

declare const Scrollbox: React.FunctionComponent<ScrollboxProps>;

export { Scrollbox as default };
