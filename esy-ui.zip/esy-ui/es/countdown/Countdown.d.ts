import React from 'react';
import { CountDownProps } from './types.js';

declare const CountDown: React.FunctionComponent<CountDownProps>;

export { CountDown as default };
