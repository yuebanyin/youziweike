interface CountDownFormat {
    day?: string;
    hour?: string;
    min?: string;
    sec?: string;
}
interface CountDownClassNames {
    box?: string;
    split?: string;
    time?: string;
}
type CountDownType = 'dd:hh:mm:ss' | 'hh:mm:ss' | 'mm:ss' | 'ss';
interface CountDownProps {
    time: number;
    onEnd?: () => void;
    format?: CountDownFormat;
    classNames?: CountDownClassNames;
    interval?: number;
    type?: CountDownType;
}

export { CountDownClassNames, CountDownFormat, CountDownProps, CountDownType };
