import React from 'react';

interface ImgClassNames {
    box?: string;
    img?: string;
}
interface ImgProps extends React.ImgHTMLAttributes<HTMLImageElement> {
    borderRadius?: number;
    cursor?: string;
    defaultUrl?: string;
    errorUrl?: string;
    classNames?: ImgClassNames;
}
interface BgImgProps extends React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement> {
    url: string;
    width?: number;
    height?: number;
    borderRadius?: number;
    cursor?: string;
    defaultUrl?: string;
    errorUrl?: string;
    classNames?: ImgClassNames;
}

export { BgImgProps, ImgClassNames, ImgProps };
