import React from 'react';
import { ImgProps, BgImgProps } from './types.js';

declare const Img: React.FunctionComponent<ImgProps>;
declare const BgImg: React.ForwardRefExoticComponent<Omit<BgImgProps, 'ref'> & React.RefAttributes<HTMLDivElement>>;

export { BgImg, Img };
