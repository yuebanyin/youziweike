import React from 'react';
import { LoadingProps } from './types.js';

declare const Loading: React.FunctionComponent<LoadingProps>;

export { Loading as default };
