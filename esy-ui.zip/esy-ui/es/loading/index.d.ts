import Loading from './Loading.js';



export { Loading as default };
