import { BaseComponent } from '../types.js';

type LoadingType = 'circle' | 'wave' | 'cube' | 'spinner';
interface LoadingClassNames {
    box?: string;
    'box:spinner'?: string;
    'child:cube'?: string;
    'child:circle'?: string;
    'child:wave'?: string;
    'child:spinner'?: string;
}
interface LoadingProps extends BaseComponent {
    loading?: boolean;
    type?: LoadingType;
    classNames?: LoadingClassNames;
    text?: string;
}

export { LoadingClassNames, LoadingProps, LoadingType };
