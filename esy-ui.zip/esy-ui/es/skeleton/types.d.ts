import { BaseComponent } from '../types.js';

interface SkeletonClassNames {
    box?: string;
    card?: string;
    animation?: string;
    content?: string;
    avatar?: string;
    article?: string;
    'article:title'?: string;
    'article:row'?: string;
}
interface SkeletonProps extends BaseComponent {
    loading: boolean;
    isTitle?: boolean;
    isCard?: boolean;
    isAvatar?: boolean;
    titleWidth?: string | number;
    cardHeight?: string | number;
    avatarSize?: string | number;
    rows?: string | number;
    rowWidth?: number | string | number[] | string[];
    cardPosition?: 'top' | 'bottom';
    classNames?: SkeletonClassNames;
}

export { SkeletonClassNames, SkeletonProps };
