import { SkeletonProps } from './types.js';
import React from 'react';

declare const Skeleton: React.FunctionComponent<SkeletonProps>;

export { Skeleton as default };
