import Skeleton from './Skeleton.js';



export { Skeleton as default };
