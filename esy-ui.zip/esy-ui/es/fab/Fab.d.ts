import React from 'react';
import { FabProps } from './types.js';

declare const Fab: React.FunctionComponent<FabProps>;

export { Fab as default };
