import { ReactNode } from 'react';
import { BaseComponent, ComponentType, ComponentTrigger, TBLRC, DivMouseType, DivTouchType } from '../types.js';

type Positon = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
interface FabClassNames {
    box?: string;
    'box:show'?: string;
    'box:hidden'?: string;
    'box:bottom-right': string;
    'box:bottom-left': string;
    'box:top-right': string;
    'box:top-left': string;
    content?: string;
    'content:default': string;
    'content:primary': string;
    'content:success': string;
    'content:warning': string;
    'content:error': string;
    'content:disabled': string;
    'content:show'?: string;
    'content:hidden'?: string;
    expand?: string;
    'expand:top'?: string;
    'expand:top:show'?: string;
    'expand:top:hiddle'?: string;
    'expand:top:dirc'?: string;
    'expand:bottom'?: string;
    'expand:bottom:show'?: string;
    'expand:bottom:hiddle'?: string;
    'expand:bottom:dirc'?: string;
    'expand:left'?: string;
    'expand:left:show'?: string;
    'expand:left:hiddle'?: string;
    'expand:left:dirc'?: string;
    'expand:right'?: string;
    'expand:right:show'?: string;
    'expand:right:hiddle'?: string;
    'expand:right:dirc'?: string;
}
interface FabProps extends BaseComponent {
    expandChildren: ReactNode;
    type?: ComponentType | 'disabled';
    show?: boolean;
    trigger?: ComponentTrigger;
    position?: Positon;
    direction?: TBLRC;
    zIndex?: number;
    isRipple?: boolean;
    classNames?: FabClassNames;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    onMouseEnter?: DivMouseType;
    onMouseLeave?: DivMouseType;
}

export { FabClassNames, FabProps, Positon };
