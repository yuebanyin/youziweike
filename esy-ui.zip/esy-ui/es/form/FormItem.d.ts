import * as react_jsx_runtime from 'react/jsx-runtime';
import { FormItemProps, FormContextProps } from './types.js';
import React from 'react';
import { FormContext } from './formContext.js';

declare class FormItem extends React.Component<FormItemProps> {
    static contextType: React.Context<FormContextProps>;
    context: React.ContextType<typeof FormContext>;
    private cancelRegister;
    private isInitialValue;
    componentDidMount(): void;
    componentWillUnmount(): void;
    onStoreChange: () => void;
    getControlled(dom: any): {
        value?: undefined;
        defaultValue?: undefined;
        label?: undefined;
        disabled?: undefined;
        readOnly?: undefined;
        error?: undefined;
        onChange?: undefined;
    } | {
        value: void;
        defaultValue: any;
        label: React.ReactNode;
        disabled: any;
        readOnly: any;
        error: string;
        onChange: (e: any) => void;
    };
    render(): react_jsx_runtime.JSX.Element;
}

export { FormItem as default };
