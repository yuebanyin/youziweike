import React from 'react';
import { FormContextProps } from './types.js';

declare const FormContext: React.Context<FormContextProps>;

export { FormContext };
