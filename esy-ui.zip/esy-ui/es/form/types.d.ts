import { ReactNode } from 'react';
import { BaseComponent, ComponentSize, Obj } from '../types.js';

interface FormClassNames {
    box?: string;
    item?: string;
    label?: string;
    control?: string;
    'error:def'?: string;
    'error:show'?: string;
    'error:hidden'?: string;
    'error:offset'?: string;
}
interface FormInstance {
    registerField: (t?: any) => () => void;
    getFieldValue: (n: string) => void;
    getFieldsValue: () => void;
    setFieldValue: (n: string, v: any, c?: boolean) => void;
    setFieldsValue: (o: Obj) => void;
    setInitFieldValue: (n: string, v: any) => void;
    getFieldError: (n: string) => string;
    onValuesChange: (Obj: any) => void;
    validate: () => void;
    reset: () => void;
    submit: () => void;
    setCallback: (Obj: any) => void;
    store: Obj;
    errList: Obj[];
}
interface FormContextProps extends FormInstance, Pick<FormItemProps, 'size' | 'colon' | 'disabled' | 'readOnly' | 'initialValues' | 'validateMessages' | 'classNames'> {
}
type ValidateMessages = 'change' | 'submit' | 'any';
interface FormProps extends BaseComponent {
    form: FormInstance;
    size?: ComponentSize;
    classNames?: FormClassNames;
    initialValues?: Obj;
    disabled?: boolean;
    readOnly?: boolean;
    colon?: boolean;
    validateMessages?: ValidateMessages;
    onFinish?: () => void;
    onFinishFailed?: () => void;
    onValuesChange?: (Obj: any) => void;
}
interface FormItemProps extends Omit<FormProps, 'form'> {
    name: string;
    label?: ReactNode;
    formlabel?: ReactNode;
    initialValue?: any;
}

export { FormClassNames, FormContextProps, FormInstance, FormItemProps, FormProps, ValidateMessages };
