import React from 'react';
import { FormProps } from './types.js';
import { useForm } from '../hooks/useForm.js';
import FormItem from './FormItem.js';

declare const Form: React.FC<FormProps> & {
    Item: typeof FormItem;
    useForm: typeof useForm;
};

export { Form as default };
