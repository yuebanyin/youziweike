import { BaseComponent } from '../types.js';

type OptionsCulmuns = {
    text: string | number;
    key: string | number;
    children?: OptionsCulmuns[];
};
interface PickerClassNames {
    box?: string;
    header?: string;
    cancel?: string;
    confirm?: string;
    content?: string;
    mask?: string;
    picked?: string;
    column?: string;
    scroll?: string;
    item?: string;
}
interface PickerProps extends BaseComponent {
    options: (OptionsCulmuns | OptionsCulmuns[])[];
    defaultValue?: (string | number)[];
    value?: (string | number)[];
    cascade?: boolean;
    pickedBoxTop?: string;
    duration?: number;
    rowHeight?: number;
    onCancel?: () => void;
    onConfirm?: (P?: any) => void;
    classNames?: PickerClassNames;
}

export { OptionsCulmuns, PickerClassNames, PickerProps };
