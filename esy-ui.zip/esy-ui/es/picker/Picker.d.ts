import { PickerProps } from './types.js';
import React from 'react';

declare const Picker: React.FunctionComponent<PickerProps>;

export { Picker as default };
