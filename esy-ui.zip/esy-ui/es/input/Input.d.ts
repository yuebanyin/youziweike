import React from 'react';
import { InputProps } from './types.js';

declare const Input: React.FunctionComponent<InputProps>;

export { Input as default };
