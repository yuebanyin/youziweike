import { FormInstance } from '../form/types.js';

declare const useForm: (form?: FormInstance) => any[];

export { useForm };
