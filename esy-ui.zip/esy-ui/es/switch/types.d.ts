import { BaseComponent, ComponentSize, DivMouseType, DivTouchType } from '../types.js';

interface SwitchClassNames {
    box?: string;
    'label:left'?: string;
    'label:right'?: string;
    'label:error'?: string;
    value?: string;
    'value:error'?: string;
    'value:disabled'?: string;
    'value:nodisabled'?: string;
    track?: string;
    'track:large'?: string;
    'track:large:active'?: string;
    'track:large:noactive'?: string;
    'track:normal'?: string;
    'track:normal:active'?: string;
    'track:normal:noactive'?: string;
    'track:small'?: string;
    'track:small:active'?: string;
    'track:small:noactive'?: string;
    'track:mini'?: string;
    'track:mini:active'?: string;
    'track:mini:noactive'?: string;
    slider?: string;
    'slider:large'?: string;
    'slider:large:active'?: string;
    'slider:large:noactive'?: string;
    'slider:normal'?: string;
    'slider:normal:active'?: string;
    'slider:normal:noactive'?: string;
    'slider:small'?: string;
    'slider:small:active'?: string;
    'slider:small:noactive'?: string;
    'slider:mini'?: string;
    'slider:mini:active'?: string;
    'slider:mini:noactive'?: string;
}
interface SwitchProps extends BaseComponent {
    label?: string;
    labelPosition?: 'left' | 'right';
    value?: boolean;
    defaultValue?: boolean;
    size?: ComponentSize;
    disabled?: boolean;
    readonly?: boolean;
    loading?: boolean;
    isRipple?: boolean;
    error?: string;
    classNames?: SwitchClassNames;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    onChange?: (p?: boolean) => void;
}

export { SwitchClassNames, SwitchProps };
