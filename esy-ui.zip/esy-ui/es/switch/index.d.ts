import Switch from './Switch.js';



export { Switch as default };
