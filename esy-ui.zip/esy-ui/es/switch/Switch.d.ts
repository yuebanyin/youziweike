import React from 'react';
import { SwitchProps } from './types.js';

declare const Switch: React.FunctionComponent<SwitchProps>;

export { Switch as default };
