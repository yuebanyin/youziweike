import React from 'react';
import { EllipsisProps } from './types.js';

declare const Ellipsis: React.FunctionComponent<EllipsisProps>;

export { Ellipsis as default };
