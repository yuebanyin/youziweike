import Ellipsis from './Ellipsis.js';



export { Ellipsis as default };
