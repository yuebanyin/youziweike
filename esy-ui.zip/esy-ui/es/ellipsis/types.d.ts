import { BaseComponent, DivMouseType, DivTouchType } from '../types.js';

interface EllipsisClassNames {
    'oe:one': string;
    'oe:mulit': string;
}
interface EllipsisProps extends BaseComponent {
    omitRow?: number;
    text: string;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    classNames?: EllipsisClassNames;
}

export { EllipsisClassNames, EllipsisProps };
