import { BaseComponent, Obj } from '../types.js';

interface ScratchProps extends BaseComponent {
    width: string | number;
    height: string | number;
    contextId?: '2d' | '3d';
    options?: Obj;
    maskText?: string;
    maskColor?: string;
    maskFont?: string;
    maskBackground?: string;
    cleanAreaRate?: number;
    drawMask?: (ctx?: any) => void;
    drawResultBg?: (canvas: HTMLCanvasElement, ctx?: any) => void;
    drawResult?: (ctx?: any) => void;
    clear?: () => void;
}

export { ScratchProps };
