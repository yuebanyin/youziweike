import React from 'react';
import { ScratchProps } from './types.js';

declare const Scratch: React.FunctionComponent<ScratchProps>;

export { Scratch as default };
