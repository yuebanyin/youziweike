import Scratch from './Scratch.js';



export { Scratch as default };
