import { MouseEvent, TouchEvent, ReactNode } from 'react';

interface BaseComponent {
    children?: ReactNode;
    className?: string;
    style?: any;
}
interface IconProps extends BaseComponent {
    onClick?: (e?: any) => void;
    onTouchStart?: (e?: any) => void;
}
type ComponentSize = 'large' | 'normal' | 'small' | 'mini';
type ComponentType = 'default' | 'primary' | 'success' | 'warning' | 'error' | 'disabled';
type ComponentTrigger = 'hover' | 'click' | 'touch';
type ComponentTarget = '_blank' | '_self' | '_parent' | '_top' | 'framename';
type MouseEventAutoHandler<T = Element> = (event: MouseEvent<T>, cb?: (p?: any) => void) => void;
type TouchEventAutoHandler<T = Element> = (event: TouchEvent<T>, cb?: (p?: any) => void) => void;
type DivMouseType = MouseEventAutoHandler<HTMLDivElement>;
type DivMouseParamType = MouseEvent<HTMLDivElement>;
type DivTouchType = TouchEventAutoHandler<HTMLDivElement>;
type DivTouchParamType = TouchEvent<HTMLDivElement>;
type TBLRC = 'top' | 'bottom' | 'left' | 'right' | 'center';
type CommonDirection = 'x' | 'y' | 'xy';
type Obj = Record<string, any>;
type Func = (p?: any) => void;
type EventClickType = 'click' | 'touch';

export { BaseComponent, CommonDirection, ComponentSize, ComponentTarget, ComponentTrigger, ComponentType, DivMouseParamType, DivMouseType, DivTouchParamType, DivTouchType, EventClickType, Func, IconProps, MouseEventAutoHandler, Obj, TBLRC, TouchEventAutoHandler };
