import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';

interface BadgeClassNames {
    box?: string;
    dot?: string;
    'dot:show'?: string;
    'dot:hidden'?: string;
    hidden?: string;
}
interface BadgeProps extends BaseComponent {
    hidden?: boolean;
    dot?: boolean;
    value?: number | ReactNode;
    maxValue?: number;
    showZero?: boolean;
    classNames?: BadgeClassNames;
}

export { BadgeClassNames, BadgeProps };
