import React from 'react';
import { BadgeProps } from './types.js';

declare const Badge: React.FunctionComponent<BadgeProps>;

export { Badge as default };
