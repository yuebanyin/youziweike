import Badge from './Badge.js';



export { Badge as default };
