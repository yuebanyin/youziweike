import { BaseComponent, DivMouseType, DivTouchType } from '../types.js';

interface CheckboxClassNames {
    box?: string;
    'box:disabled'?: string;
    'box:nodisabled'?: string;
    value?: string;
    'value:normal'?: string;
    'value:disabled'?: string;
    'value:checked'?: string;
    label?: string;
    'label:disabled'?: string;
    'label:nodisabled'?: string;
}
interface CheckboxProps extends BaseComponent {
    label?: string;
    defaultChecked?: boolean;
    checked?: boolean;
    value?: string | number;
    disabled?: boolean;
    readOnly?: boolean;
    classNames?: CheckboxClassNames;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    onChange?: (e: any) => void;
}

export { CheckboxClassNames, CheckboxProps };
