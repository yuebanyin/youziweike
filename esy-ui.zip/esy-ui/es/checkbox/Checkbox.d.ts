import { CheckboxProps } from './types.js';
import Group from '../group/Group.js';
import React from 'react';

declare const Checkbox: React.FC<CheckboxProps> & {
    Group: typeof Group;
};

export { Checkbox as default };
