import { BaseComponent, DivMouseType, DivTouchType } from '../types.js';

interface RadioClassNames {
    box: string;
    disabled: string;
    label: string;
    value: string;
    'value:disabled': string;
    'value:hover': string;
    'value:checked': string;
}
interface RadioProps extends BaseComponent {
    classNames?: RadioClassNames;
    label?: string;
    defaultChecked?: boolean;
    checked?: boolean;
    value?: string | number;
    disabled?: boolean;
    readOnly?: boolean;
    onClick?: DivMouseType;
    onTouchStart?: DivTouchType;
    onChange?: (e: any) => void;
}

export { RadioClassNames, RadioProps };
