import { RadioProps } from './types.js';
import React from 'react';
import Group from '../group/Group.js';

declare const Radio: React.FC<RadioProps> & {
    Group: typeof Group;
};

export { Radio as default };
