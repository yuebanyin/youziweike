interface VerticalScrollItem {
    id: number | string;
    text: string;
    url?: string;
}
interface VerticalScrollClassNames {
    box?: string;
    list?: string;
    transition?: string;
    text?: string;
}
interface VerticalScrollProps {
    list: VerticalScrollItem[];
    speedRate?: number;
    onClick?: (info?: VerticalScrollItem) => void;
    onTouchStart?: (info?: VerticalScrollItem) => void;
    classNames?: VerticalScrollClassNames;
}

export { VerticalScrollClassNames, VerticalScrollItem, VerticalScrollProps };
