import React from 'react';
import { VerticalScrollProps } from './types.js';

declare const VerticalScroll: React.FunctionComponent<VerticalScrollProps>;

export { VerticalScroll as default };
