import Table from './Table.js';



export { Table as default };
