import { ReactNode } from 'react';
import { BaseComponent, Obj } from '../types.js';

interface TableClassNames {
    box?: string;
    table?: string;
    header?: string;
    tbody?: string;
    body?: string;
    footer?: string;
    tr?: string;
    'tr:header'?: string;
    'tr:body'?: string;
    'tr:footer'?: string;
    td?: string;
    'td:xy'?: string;
    'td:x'?: string;
    'td:y'?: string;
    'td:xy:scroll'?: string;
    'td:x:scroll'?: string;
    'td:y:scroll'?: string;
    'td:xy:first:body'?: string;
    'td:y:first:body'?: string;
    'td:xy:last:body'?: string;
    'td:y:last:body'?: string;
    'td:xy:scroll:first:body'?: string;
    'td:y:scroll:first:body'?: string;
    'td:xy:scroll:last:body'?: string;
    'td:y:scroll:last:body'?: string;
    'td:align:l'?: string;
    'td:align:c'?: string;
    'td:align:r'?: string;
    'td:fixed'?: string;
    'td:cover'?: string;
    'td:cover:xy'?: string;
    'td:cover:x'?: string;
    'td:cover:y'?: string;
}
type TextAlign = 'l' | 'c' | 'r';
interface ColumnProps {
    key: string;
    title: ReactNode;
    align?: TextAlign;
    sorter?: Function | boolean;
    render?: Function;
    fixed?: boolean;
}
interface TableProps extends BaseComponent {
    columns: ColumnProps[];
    footerColumns?: ColumnProps[];
    data: Obj[];
    footerData?: [];
    bordered?: boolean | 'x' | 'y';
    showHeader?: boolean;
    showFooter?: boolean;
    onTrClick?: Function;
    empty?: ReactNode;
    footer?: ReactNode;
    classNames?: TableClassNames;
}

export { ColumnProps, TableClassNames, TableProps, TextAlign };
