import React from 'react';
import { TableProps } from './types.js';

declare const Table: React.FunctionComponent<TableProps>;

export { Table as default };
