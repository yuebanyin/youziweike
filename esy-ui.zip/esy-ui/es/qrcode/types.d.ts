interface QRClassNames {
    box?: string;
}
interface QRCodeProps {
    value: string;
    mode?: 'canvas' | 'svg';
    size?: number;
    bgColor?: string;
    fgColor?: string;
    level?: 'L' | 'M' | 'Q' | 'H';
    includeMargin?: boolean;
    imageSettings?: ImageSettings;
    classNames?: QRClassNames;
    boxClassName?: string;
}
interface ImageSettings {
    src: string;
    x: number;
    y: number;
    height: number;
    width: number;
    excavate: boolean;
}

export { ImageSettings, QRClassNames, QRCodeProps };
