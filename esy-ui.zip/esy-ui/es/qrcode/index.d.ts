import QRCode from './QRcode.js';



export { QRCode as default };
