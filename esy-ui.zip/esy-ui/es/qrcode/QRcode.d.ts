import React from 'react';
import { QRCodeProps } from './types.js';

declare const QRCode: React.FunctionComponent<QRCodeProps>;

export { QRCode as default };
