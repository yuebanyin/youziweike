import { DropdownProps } from './types.js';
import React from 'react';

declare const Dropdown: React.FunctionComponent<DropdownProps>;

export { Dropdown as default };
