import { ReactNode } from 'react';
import { BaseComponent } from '../types.js';

interface DropdownClassNames {
    box?: string;
    dropwrap?: string;
    dropdown?: string;
    'dropdown:expand'?: string;
    'dropdown:retract'?: string;
    options?: string;
    'options:expand'?: string;
    'options:retract'?: string;
}
interface DropdownProps extends BaseComponent {
    targetNode?: ReactNode;
    dropdownNode?: ReactNode;
    isDropClose?: boolean;
    classNames?: DropdownClassNames;
}

export { DropdownClassNames, DropdownProps };
